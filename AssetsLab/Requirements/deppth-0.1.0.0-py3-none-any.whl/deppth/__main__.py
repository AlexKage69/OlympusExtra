"""__main__: executed when deppth directory is called as a script."""

from .deppth import main
main()